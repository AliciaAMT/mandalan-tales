// src/app/shared/standalone-imports.ts
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';

export const STANDALONE_IMPORTS = [
  IonicModule,
  CommonModule
];
